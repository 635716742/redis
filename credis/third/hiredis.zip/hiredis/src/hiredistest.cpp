// hiredistest.cpp: 定义控制台应用程序的入口点。
//

#include "stdafx.h"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "hiredis.h"
#include "hiredis.h"
#include "async.h"
#include "WinSock2.h"

int main(int argc, char **argv) {
	redisAsyncContext *c = redisAsyncConnect("127.0.0.1", 6379);
	if (c->err) {
		/* Let *c leak for now... */
		printf("Error: %s\n", c->errstr);
		return 1;
	}
	
	redisAsyncFree(c);
	return 0;
}
