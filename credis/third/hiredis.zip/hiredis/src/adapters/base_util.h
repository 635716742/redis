#ifndef __HIREDIS_BASE_UTIL_H__
#define __HIREDIS_BASE_UTIL_H__
#include <platform/platform_shared/BiboFrame/BiboInterfaces.h>
#include "../async.h"


class RedisAsyncAdapter : public IReadCallback, IWriteCallback, INoticeCallback
{
public:
	RedisAsyncAdapter(redisAsyncContext* context) : m_context(context), m_ev_sel(GetBiboRegistry()->GetApplication()->GetEventSelector()), m_read_added(false), m_write_added(false), m_err(false)
	{}

	void redisBaseUtilAddRead()
	{
		if (!m_read_added)
		{
			m_ev_sel->PostReadReq(_sock_id(), this, NULL);
			m_read_added = true;
		}
	}

	void redisBaseUtilDelRead()
	{
		if (m_read_added)
		{
			m_ev_sel->CancelReadReq(_sock_id());
			m_read_added = false;
		}
	}

	void redisBaseUtilAddWrite()
	{
		if (!m_write_added)
		{
			m_ev_sel->PostWriteReq(_sock_id(), 0, 0, this, NULL);
			m_write_added = true;
		}
	}

	void redisBaseUtilDelWrite()
	{
		if (m_write_added)
		{
			m_ev_sel->CancelWriteReq(_sock_id());
			m_write_added = false;
		}
	}

	//��ʱɾ����selector�������ڵ�����
	void Release()
	{
		if (!m_err)
		{
			m_ev_sel->DelFD(_sock_id());

			m_err = true;
			m_ev_sel->NotifyEvent(this, NULL);
		}
	}

	virtual void OnRead(void* user_ptr, char* buf, int bytes_read, sockaddr_in* remote_addr)
	{
		redisAsyncHandleRead(m_context);
	}

	virtual void OnReadError(void* user_ptr, int error)
	{
		if (!m_err)
		{
			LogError("[redis] adapter on read err.");
			redisAsyncHandleRead(m_context);
		}
	}

	virtual void OnWritten(void* user_ptr, int bytes_written)
	{
		redisAsyncHandleWrite(m_context);
	}

	virtual void OnWriteError(void* user_ptr, int error)
	{
		if (!m_err)
		{
			LogError("[redis] adapter on write err.");
			redisAsyncHandleWrite(m_context);
		}
	}

	virtual void OnNotice(void* user_ptr)
	{
	}

	virtual void ReleaseNoticeCallback()
	{
		delete this;
	}

protected:
	int _sock_id(){
		return m_context->c.fd;
	}

	redisAsyncContext* m_context;
	IEventSelector* m_ev_sel;
	bool m_read_added;
	bool m_write_added;
	bool m_err;
};

static void redisBaseUtilAddRead(void *privdata) 
{
	RedisAsyncAdapter* adapter = (RedisAsyncAdapter*)privdata;
	return adapter->redisBaseUtilAddRead();
}

static void redisBaseUtilDelRead(void *privdata) 
{
	RedisAsyncAdapter* adapter = (RedisAsyncAdapter*)privdata;
	return adapter->redisBaseUtilDelRead();
}

static void redisBaseUtilAddWrite(void *privdata) 
{
	RedisAsyncAdapter* adapter = (RedisAsyncAdapter*)privdata;
	return adapter->redisBaseUtilAddWrite();
}

static void redisBaseUtilDelWrite(void *privdata) 
{
	RedisAsyncAdapter* adapter = (RedisAsyncAdapter*)privdata;
	return adapter->redisBaseUtilDelWrite();
}

static void redisBaseUtilCleanup(void *privdata) 
{
	RedisAsyncAdapter* adapter = (RedisAsyncAdapter*)privdata;
	return adapter->Release();
}

static int redisBaseUtilAttach(redisAsyncContext *ac) 
{
    redisContext *c = &(ac->c);

    /* Nothing should be attached when something is already attached */
    if (ac->ev.data != NULL)
        return REDIS_ERR;

    /* Create container for context and r/w events */
	ac->ev.data = new RedisAsyncAdapter(ac);
    /* Register functions to start/stop listening for events */
    ac->ev.addRead = redisBaseUtilAddRead;
    ac->ev.delRead = redisBaseUtilDelRead;
    ac->ev.addWrite = redisBaseUtilAddWrite;
    ac->ev.delWrite = redisBaseUtilDelWrite;
    ac->ev.cleanup = redisBaseUtilCleanup;

    /* Initialize and install read/write events */
    return REDIS_OK;
}
#endif
